package com.serpilozguven.artbooktesting.view

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.serpilozguven.artbooktesting.R

class ArtFragment: Fragment(R.layout.fragments_arts) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}