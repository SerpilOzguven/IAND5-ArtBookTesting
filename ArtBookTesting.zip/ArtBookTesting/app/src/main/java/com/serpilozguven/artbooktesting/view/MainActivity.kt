package com.serpilozguven.artbooktesting.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.serpilozguven.artbooktesting.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}